#pragma once 

#include <ntifs.h>

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriveObject, PUNICODE_STRING pRegisteryPath);

NTSTATUS UnloadDriver(PDRIVER_OBJECT pDriverObject);