#pragma warning (disable : 4100)

#include "FIRSTDRIVER.h"

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriveObject, PUNICODE_STRING pRegisteryPath)
{
	pDriveObject->DriverUnload = UnloadDriver;

	return STATUS_SUCCESS;
}

NTSTATUS UnloadDriver(PDRIVER_OBJECT pDriverObject)
{
	return STATUS_SUCCESS;
}